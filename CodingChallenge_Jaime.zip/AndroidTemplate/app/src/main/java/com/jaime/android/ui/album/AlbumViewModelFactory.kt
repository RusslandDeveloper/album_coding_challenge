package com.jaime.android.ui.album

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.jaime.android.repository.Repository
import java.lang.IllegalArgumentException

class AlbumViewModelFactory(private val repository: Repository) : ViewModelProvider.Factory {
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        if(modelClass.isAssignableFrom(AlbumViewModel::class.java)){
            return AlbumViewModel(repository) as T
        }
        throw IllegalArgumentException("Wrong ViewModel")
    }
}