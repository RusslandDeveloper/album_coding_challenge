package com.jaime.android.ui.album

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.RecyclerView
import com.jaime.android.R
import com.jaime.android.adapter.AlbumAdapter
import com.jaime.android.data.Result
import com.jaime.android.repository.Repository
import com.jaime.android.ui.FragmentDetails
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class FragmentAlbum: Fragment(R.layout.fragment_album), AlbumAdapter.onClickListener {

    lateinit var recyclerView: RecyclerView

    lateinit var viewModel: AlbumViewModel
    lateinit var viewModelFactory: AlbumViewModelFactory
    lateinit var repository: Repository

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recyclerView = view.findViewById(R.id.recyclerview_album)
        
        repository = Repository()
        viewModelFactory = AlbumViewModelFactory(repository)
        viewModel = ViewModelProvider(this,viewModelFactory).get(AlbumViewModel::class.java)

        viewModel.liveResponse.observe(viewLifecycleOwner, Observer {

          recyclerView.adapter = AlbumAdapter(it,this)
            recyclerView.setHasFixedSize(true)
        })


    }

    override fun onItemCLick(datasource: Result) {


        val bundle = Bundle()

        bundle.putString("ImageURL",datasource.artworkUrl100)
        bundle.putString("Title", datasource.name)
        bundle.putString("Author", datasource.artistName)
        val manager = parentFragmentManager.beginTransaction()

        val fragment = FragmentDetails.newInstance(datasource)

        manager.replace(R.id.fragment_container_view_album,fragment)
            .addToBackStack("FragmentAlbum")
            .commit()
    }

}
