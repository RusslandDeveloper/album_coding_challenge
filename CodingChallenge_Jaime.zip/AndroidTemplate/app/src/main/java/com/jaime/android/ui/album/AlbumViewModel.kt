package com.jaime.android.ui.album

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jaime.android.data.Album
import com.jaime.android.data.Result
import com.jaime.android.repository.Repository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlbumViewModel(private val repository: Repository) : ViewModel() {

    private var response : Album? = null
     val liveResponse : MutableLiveData<List<Result>> = MutableLiveData()

    init {
        fetchData()
    }

    private fun fetchData(){
       viewModelScope.launch (Dispatchers.IO){
           response = repository.getContact()
           liveResponse.postValue(response?.feed?.results)

       }

    }


}