package com.jaime.android.repository

import com.jaime.android.api.RetrofitInstance
import com.jaime.android.data.Album
import com.jaime.android.data.Feed
import com.jaime.android.data.Result

class Repository {

    suspend fun getContact():Album{
        return RetrofitInstance.api.getAlbumAPI()
    }
}