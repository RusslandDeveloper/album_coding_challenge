package com.jaime.android.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.jaime.android.R
import com.jaime.android.data.Result

class FragmentDetails() : Fragment(R.layout.fragment_details) {

    lateinit var imageViewMusic: ImageView
    lateinit var textTitle: TextView
    lateinit var textAuthor : TextView

     private var imageUri : String? = ""
    private var title : String? = ""
    private var author : String? = ""


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val bundle = arguments

        imageUri = bundle?.getString("ImageURL")
        title = bundle?.getString("Title")
        author = bundle?.getString("Author")

        imageViewMusic = view.findViewById(R.id.image_details)
        textTitle = view.findViewById(R.id.txtview_details_title)
        textAuthor = view.findViewById(R.id.txtview_details_author)
        Glide.with(view.context)
            .load(imageUri)
            .into(imageViewMusic)
        textTitle.text = title
        textAuthor.text = author

    }

    companion object{
        const val imageURI  = "ImageURL"
        const val Title  = "Title"
        const val Author  = "Author"

        fun newInstance( datasource: Result ): FragmentDetails {
            val fragment = FragmentDetails()
            val bundle = Bundle().apply {
                putString(imageURI,datasource.artworkUrl100 )
                putString(Title,datasource.name )
                putString(Author,datasource.artistName)
            }

            fragment.arguments = bundle
            return fragment
        }



    }
}