package com.jaime.android.api

import com.jaime.android.data.Album

import retrofit2.http.GET

interface AlbumAPI {
    @GET("/api/v1/us/apple-music/coming-soon/all/10/explicit.json")
    suspend fun getAlbumAPI(): Album
}