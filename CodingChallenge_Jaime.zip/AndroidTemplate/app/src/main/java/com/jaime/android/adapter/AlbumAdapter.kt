package com.jaime.android.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.jaime.android.R
import com.jaime.android.data.Album
import com.jaime.android.data.Result
import kotlinx.coroutines.DEBUG_PROPERTY_VALUE_AUTO

class AlbumAdapter(private val datasource: List<Result>, private val listener:onClickListener):RecyclerView.Adapter<AlbumAdapter.AlbumViewHolder>() {

   inner class AlbumViewHolder(private val view: View): RecyclerView.ViewHolder(view), View.OnClickListener{
        val albumImage: ImageView = view.findViewById(R.id.image_album)
        val textTitle : TextView = view.findViewById(R.id.textview_title)
        val textAuthor : TextView = view.findViewById(R.id.textview_author)

        init {
            itemView.setOnClickListener(this)
        }
        override fun onClick(p0: View?) {
           val position = adapterPosition
            listener.onItemCLick(datasource[position])
        }
    }

    interface onClickListener{
        fun onItemCLick(datasource: Result)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AlbumViewHolder {
       val albumViewHolder = LayoutInflater.from(parent.context).inflate(R.layout.item_layout
           ,parent, false)
        return AlbumViewHolder(albumViewHolder)

    }

    override fun onBindViewHolder(holder: AlbumViewHolder, position: Int) {
       val item = datasource[position]

        Glide.with(holder.albumImage.context)
            .load(item.artworkUrl100)
            .into(holder.albumImage)

        holder.textTitle.text = item.name
        holder.textAuthor.text = item.artistName

    }
    override fun getItemCount() = datasource.size
}