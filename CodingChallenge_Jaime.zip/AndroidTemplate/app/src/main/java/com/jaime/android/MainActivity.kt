package com.jaime.android

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.jaime.android.ui.album.FragmentAlbum

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val fragmentManager = supportFragmentManager.beginTransaction()

        fragmentManager.replace(R.id.fragment_container_view_album, FragmentAlbum()).commit()


    }
}